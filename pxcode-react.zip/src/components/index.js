import Home_page from './Home_page';

export default { Home_page };
