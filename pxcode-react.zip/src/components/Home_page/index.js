import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

import renderSection3 from './section3.js';
import renderSection4 from './section4.js';
import renderSection5 from './section5.js';
import renderSection6 from './section6.js';
import renderSection7 from './section7.js';
import renderSection9 from './section9.js';
import renderSection10 from './section10.js';
import renderSection2 from './section2.js';
import renderSection1 from './section1.js';
import renderSection11 from './section11.js';
import renderSection13 from './section13.js';
import renderSection14 from './section14.js';
import renderSection8 from './section8.js';
import renderSection12 from './section12.js';

import styles from './index.module.scss';

function Home_page(props) {
  return (
    <div className={cn(styles.root, props.className, 'home-page')}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      {renderSection3(props)}
      {renderSection4(props)}
      {renderSection5(props)}
      {renderSection6(props)}
      {renderSection7(props)}
      {renderSection9(props)}
      {renderSection10(props)}
      {renderSection2(props)}
      <div className={styles.group1}>{renderSection1(props)}</div>
      {renderSection11(props)}
      {renderSection13(props)}
      {renderSection14(props)}
      {renderSection8(props)}
      {renderSection12(props)}
    </div>
  );
}

Home_page.propTypes = {
  className: PropTypes.string
};

export default Home_page;
