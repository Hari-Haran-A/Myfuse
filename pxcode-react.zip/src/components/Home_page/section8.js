import React from 'react';
import cn from 'classnames';

import section8Styles from './section8.module.scss';

function renderSection8(props) {
  return (
    <section className={section8Styles.section8}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <div className={section8Styles.rect15} />
      <div className={section8Styles.box7}>
        <h2 className={section8Styles.medium_title}>CATEGORIES</h2>
      </div>
      <div
        className={section8Styles.box8}
        style={{ '--src': `url(${'/assets/b015c47743323a1761d702a99eed2e2c.png'})` }}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <img className={section8Styles.image26} src={'/assets/ed79bda498b7a0e14f37899f9290a316.png'} alt="alt text" />
        <h5 className={section8Styles.highlight11}>Education</h5>
      </div>
      <div className={section8Styles.box9}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <img className={section8Styles.image261} src={'/assets/cad94e603b09d33feabaeb691d6c762e.png'} alt="alt text" />
        <h5 className={section8Styles.highlight12}>Retail and customer</h5>
      </div>
      <div className={section8Styles.box10}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <img className={section8Styles.image262} src={'/assets/3b1a829ae4a562f5c193f56084036b77.png'} alt="alt text" />
        <h5 className={section8Styles.highlight13}>Engineering and Manufacturing</h5>
      </div>
      <div className={section8Styles.box11}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <img className={section8Styles.image27} src={'/assets/7d79cc29999b21ed07ea2aa1ae427fbb.png'} alt="alt text" />
        <h5 className={section8Styles.highlight131}>Transportation and Logistics</h5>
      </div>
      <div className={section8Styles.box12}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <img className={section8Styles.image28} src={'/assets/172e4e5afd0c0b41c69d0a7654cd507b.png'} alt="alt text" />
        <h5 className={section8Styles.highlight132}>Travel and tourism</h5>
      </div>
      <div className={section8Styles.box13}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <img className={section8Styles.image263} src={'/assets/75813f7c84ce1002fe686f7ac0eeef67.png'} alt="alt text" />
        <h5 className={section8Styles.highlight133}>Technology And IT</h5>
      </div>
      <div className={section8Styles.box131}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <img className={section8Styles.image264} src={'/assets/e24de45331ec30a132acac103745b7ac.png'} alt="alt text" />
        <h5 className={section8Styles.highlight134}>Health Care</h5>
      </div>
      <div className={section8Styles.box132}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <img className={section8Styles.image263} src={'/assets/e4d00565429a490019d78ae028ed590c.png'} alt="alt text" />
        <h5 className={section8Styles.highlight135}>Finance and banking</h5>
      </div>
      <div className={section8Styles.rect16} />
      <h2 className={section8Styles.medium_title5}>Recommend Jobs</h2>
      <img className={section8Styles.image265} src={'/assets/27ffec6c9be16477f65886ee6bafa18d.png'} alt="alt text" />
      <div className={section8Styles.rect18} />
      <img className={section8Styles.image30} src={'/assets/4b94f12b18c3892116f64c66fdf2ce67.png'} alt="alt text" />
      <h5 className={section8Styles.highlight16}>Search Job Title...</h5>
      <div className={section8Styles.rect19} />
      <img className={section8Styles.image301} src={'/assets/c036d570e95474e2634c4a1b172de731.png'} alt="alt text" />
      <h5 className={section8Styles.highlight161}>Location</h5>
      <img className={section8Styles.image31} src={'/assets/9cbc6ca1f0877316075db4daa7f82a46.png'} alt="alt text" />
      <div className={section8Styles.text4}>Search</div>
      <h5 className={section8Styles.highlight17}>Sort by</h5>
      <div className={section8Styles.rect20} />
      <h5 className={section8Styles.highlight171}>Relevance</h5>
      <img className={section8Styles.image32} src={'/assets/7a0518861234f23932db5e4e760fd842.png'} alt="alt text" />
      <h5 className={section8Styles.highlight172}>Type</h5>
      <div className={section8Styles.rect201} />
      <h5 className={section8Styles.highlight173}>Full Time</h5>
      <img className={section8Styles.image321} src={'/assets/7a0518861234f23932db5e4e760fd842.png'} alt="alt text" />
      <h5 className={section8Styles.highlight174}>Industry</h5>
      <div className={section8Styles.rect202} />
      <h5 className={section8Styles.highlight175}>Education</h5>
      <img className={section8Styles.image322} src={'/assets/7a0518861234f23932db5e4e760fd842.png'} alt="alt text" />
      <div className={section8Styles.box18}>
        <h5 className={section8Styles.highlight18}>Clear..</h5>
      </div>
      <img className={section8Styles.image33} src={'/assets/3530b429482cef126280f400c3a0d555.png'} alt="alt text" />
      <div className={section8Styles.box19}>
        <h5 className={section8Styles.highlight181}>Full Time</h5>
      </div>
      <h3 className={section8Styles.subtitle1}>Deloitte</h3>
      <h5 className={section8Styles.highlight19}>Technology and IT</h5>
      <img className={section8Styles.image21} src={'/assets/2504a437efd8c60c81ced7b8af20750b.png'} alt="alt text" />
      <h5 className={section8Styles.highlight20}>Bengaluru</h5>
      <h5 className={section8Styles.highlight21}>Job Role : Associate Analyst</h5>
      <h5 className={section8Styles.highlight22}>Salary : 4-5 LPA</h5>
      <img className={section8Styles.cover8} src={'/assets/0ce5c875e1a80e2ba75cdd6cb6e9fb4d.png'} alt="alt text" />
      <h5 className={section8Styles.highlight23}>Apply Job</h5>
      <img className={section8Styles.image331} src={'/assets/0afbc99ce7bc39e223cff0c843b9608d.png'} alt="alt text" />
      <div className={section8Styles.box191}>
        <h5 className={section8Styles.highlight181}>Full Time</h5>
      </div>
      <h3 className={section8Styles.subtitle11}>Airbus</h3>
      <h5 className={section8Styles.highlight191}>Technology and IT</h5>
      <img className={section8Styles.image211} src={'/assets/2504a437efd8c60c81ced7b8af20750b.png'} alt="alt text" />
      <h5 className={section8Styles.highlight201}>Bengaluru</h5>
      <h5 className={section8Styles.highlight211}>Job Role : Data Analyst</h5>
      <h5 className={section8Styles.highlight221}>Salary : 3.5-5 LPA</h5>
      <img className={section8Styles.cover81} src={'/assets/0ce5c875e1a80e2ba75cdd6cb6e9fb4d.png'} alt="alt text" />
      <h5 className={section8Styles.highlight231}>Apply Job</h5>
      <img className={section8Styles.image34} src={'/assets/aaab47e6c9b974c4617805d73dd06811.png'} alt="alt text" />
      <div className={section8Styles.box192}>
        <h5 className={section8Styles.highlight181}>Full Time</h5>
      </div>
      <h3 className={section8Styles.subtitle12}>Bajaj Allianz</h3>
      <h5 className={section8Styles.highlight192}>Technology and IT</h5>
      <img className={section8Styles.image212} src={'/assets/2504a437efd8c60c81ced7b8af20750b.png'} alt="alt text" />
      <h5 className={section8Styles.highlight202}>Begusarai – Ext</h5>
      <h5 className={section8Styles.highlight212}>Job Role : Junior Service Engineer</h5>
      <h5 className={section8Styles.highlight222}>Salary : 3 -5 LPA</h5>
      <img className={section8Styles.cover82} src={'/assets/0ce5c875e1a80e2ba75cdd6cb6e9fb4d.png'} alt="alt text" />
      <h5 className={section8Styles.highlight232}>Apply Job</h5>
      <img className={section8Styles.image341} src={'/assets/8834a97bdb3d52fa9b3caff7d5e23e23.png'} alt="alt text" />
      <div className={section8Styles.box193}>
        <h5 className={section8Styles.highlight181}>Full Time</h5>
      </div>
      <h3 className={section8Styles.subtitle13}>Amdocs</h3>
      <h5 className={section8Styles.highlight193}>Technology and IT</h5>
      <img className={section8Styles.image213} src={'/assets/2504a437efd8c60c81ced7b8af20750b.png'} alt="alt text" />
      <h5 className={section8Styles.highlight203}>Pune, Maharashtra</h5>
      <h5 className={section8Styles.highlight213}>Job Role :  IT Professional – Windows /OS </h5>
      <h5 className={section8Styles.highlight223}>Salary : 4-5 LPA</h5>
      <img className={section8Styles.cover83} src={'/assets/0ce5c875e1a80e2ba75cdd6cb6e9fb4d.png'} alt="alt text" />
      <h5 className={section8Styles.highlight233}>Apply Job</h5>
      <div className={section8Styles.box20}>
        <h5 className={section8Styles.highlight24}>Load more</h5>
      </div>
    </section>
  );
}

export default renderSection8;
