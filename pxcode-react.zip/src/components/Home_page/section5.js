import React from 'react';
import cn from 'classnames';

import section5Styles from './section5.module.scss';

function renderSection5(props) {
  return (
    <section className={section5Styles.section5}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <div className={section5Styles.rect2} />
      <h1 className={section5Styles.hero_title}>PARTNERED COMPANIES</h1>
      <img className={section5Styles.image9} src={'/assets/e99c0fa185e12e528e55f48c9a9e5052.png'} alt="alt text" />
    </section>
  );
}

export default renderSection5;
