import React from 'react';
import cn from 'classnames';

import section2Styles from './section2.module.scss';

function renderSection2(props) {
  return (
    <section className={section2Styles.section2}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <img className={section2Styles.image19} src={'/assets/48c3718df7f9a81e732ffd43666cafec.png'} alt="alt text" />
      <div className={section2Styles.rect6} />
      <div className={section2Styles.text2}>2500+</div>
      <div className={section2Styles.text3}>Active Students</div>
      <img className={section2Styles.image191} src={'/assets/08856ca495677207c0647c8475b9fec7.png'} alt="alt text" />
      <div className={section2Styles.rect7} />
      <div className={section2Styles.text21}>3000+</div>
      <div className={section2Styles.text31}>Jobs</div>
      <img className={section2Styles.image192} src={'/assets/92d7eba8320f114c365c21c63b962b23.png'} alt="alt text" />
      <div className={section2Styles.rect61} />
      <div className={section2Styles.text22}>5500+</div>
      <div className={section2Styles.text32}>Active Applications</div>
      <h3 className={section2Styles.subtitle2}>
        Discover a world of opportunities with internships, projects, and a gateway to your professional future. Join a
        vibrant community that paves the way to success.
      </h3>
      <h1 className={section2Styles.hero_title}>Opening Doors to Endless </h1>
      <img className={section2Styles.image20} src={'/assets/50e4e3c15327aee7d2f704d9e81a3aa7.png'} alt="alt text" />
      <div className={section2Styles.rect8} />
      <h3 className={section2Styles.subtitle3}>Get Started</h3>
      <img className={section2Styles.image21} src={'/assets/67b4395877d42f0cea824161b7ddc5ad.png'} alt="alt text" />
      <img className={section2Styles.image22} src={'/assets/e3a4eced51044ab36a7ad49c53424411.png'} alt="alt text" />
      <img className={section2Styles.image23} src={'/assets/8224307dbbf33b1668d392a73f0fe42b.png'} alt="alt text" />
    </section>
  );
}

export default renderSection2;
