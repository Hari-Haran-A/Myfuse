import React from 'react';
import cn from 'classnames';

import section1Styles from './section1.module.scss';

function renderSection1(props) {
  return (
    <section className={section1Styles.section1}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <img className={section1Styles.image24} src={'/assets/62e6b4bb68fcd074dcb26a318c727f1e.png'} alt="alt text" />
      <h4 className={section1Styles.highlight8}>Home</h4>
      <h4 className={section1Styles.highlight81}>Challenges</h4>
      <h4 className={section1Styles.highlight82}>Jobs</h4>
      <h4 className={section1Styles.highlight83}>Blogs</h4>
      <h4 className={section1Styles.highlight84}>Contact</h4>
      <div className={section1Styles.rect9} />
      <h4 className={section1Styles.highlight9}>Open the gateway</h4>
    </section>
  );
}

export default renderSection1;
