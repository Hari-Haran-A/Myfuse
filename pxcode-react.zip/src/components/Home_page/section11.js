import React from 'react';
import cn from 'classnames';

import section11Styles from './section11.module.scss';

function renderSection11(props) {
  return (
    <section className={section11Styles.section11}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <h1 className={section11Styles.hero_title3}>Reviews from MyFuse Graduates</h1>
      <div className={section11Styles.rect10} />
      <div className={section11Styles.rect101} />
      <div className={section11Styles.rect102} />
      <div className={section11Styles.rect103} />
      <div className={section11Styles.rect11} />
      <div className={section11Styles.rect111} />
      <div className={section11Styles.rect112} />
      <div className={section11Styles.rect113} />
      <div className={section11Styles.box14}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <h5 className={section11Styles.highlight14}>
          As a seasoned designer always on the lookout for innovative tools, MyFuse.in instantly grabbed my attention
        </h5>
        <img className={section11Styles.image29} src={'/assets/0cb59221747b37b0fdc3cb66fb8ef7e7.png'} alt="alt text" />
        <h5 className={section11Styles.highlight15}>Alex Rivera</h5>
        <h5 className={section11Styles.highlight141}>@jamietechguru00</h5>
      </div>
      <div className={section11Styles.box15}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <h5 className={section11Styles.highlight142}>
          Its user-friendly interface and robust features support our diverse needs.
        </h5>
        <img className={section11Styles.image291} src={'/assets/1aec94f6c19349d219a36003c04b10b7.png'} alt="alt text" />
        <h5 className={section11Styles.highlight151}>Casey Harper</h5>
        <h5 className={section11Styles.highlight143}>@casey09</h5>
      </div>
      <div className={section11Styles.box16}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <h5 className={section11Styles.highlight144}>
          The customizability and integration capabilities of this app are top-notch.
        </h5>
        <img className={section11Styles.image292} src={'/assets/8562d46f14f5cae8c7912877399a8dc8.png'} alt="alt text" />
        <h5 className={section11Styles.highlight152}>Riley Smith</h5>
        <h5 className={section11Styles.highlight145}>@rileysmith1</h5>
      </div>
      <div className={section11Styles.box17}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <h5 className={section11Styles.highlight146}>
          This app has completely transformed how I manage my projects and deadlines.
        </h5>
        <img className={section11Styles.image293} src={'/assets/ea4fbe9f3d2db5dffb816c8e4b627036.png'} alt="alt text" />
        <h5 className={section11Styles.highlight153}>Morgan Lee</h5>
        <h5 className={section11Styles.highlight147}>@morganleewhiz</h5>
      </div>
    </section>
  );
}

export default renderSection11;
