import React from 'react';
import cn from 'classnames';

import section4Styles from './section4.module.scss';

function renderSection4(props) {
  return (
    <section className={section4Styles.section4}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <div className={section4Styles.rect1} />
      <h3 className={section4Styles.subtitle1}>
        Myfuse, the ultimate student job portal, offers limitless professional options to explore in India.
      </h3>
      <img className={section4Styles.image5} src={'/assets/209026034591ca2e6b87d320c6fdd22d.png'} alt="alt text" />
      <img className={section4Styles.image51} src={'/assets/844f7c72dedf90c9cdf127477f1f532b.png'} alt="alt text" />
      <img className={section4Styles.image52} src={'/assets/03aeae10b947ef30c87ca02de5667a1c.png'} alt="alt text" />
      <img className={section4Styles.image53} src={'/assets/55fb25425f4147bd706426bf5fdd7636.png'} alt="alt text" />
      <h2 className={section4Styles.medium_title1}>Right Job for you</h2>
      <h2 className={section4Styles.medium_title2}>{`One to One Conversation With HR's`}</h2>
      <h2 className={section4Styles.medium_title21}>No Work Experience required</h2>
      <h2 className={section4Styles.medium_title22}>Easy To Apply</h2>
      <h5
        className={
          section4Styles.highlight2
        }>{`Finding the perfect job is easier with Myfuse's comprehensive platform.`}</h5>
      <h5 className={section4Styles.highlight21}>
        provides the special benefit of having one-on-one discussions with HR specialists
      </h5>
      <h5 className={section4Styles.highlight22}>
        encourages applications from candidates without any prior work experience and offers helpful resources and
        opportunities.
      </h5>
      <h5 className={section4Styles.highlight23}>A simple application procedure makes it simple to apply.</h5>
      <h1 className={section4Styles.hero_title}>JOB FUSE</h1>
      <img className={section4Styles.image6} src={'/assets/bcb85c62191a97912f484f5ba489d4b7.png'} alt="alt text" />
      <img className={section4Styles.cover2} src={'/assets/d2d65aa573a40364d724cb33b1fba16d.png'} alt="alt text" />
      <img className={section4Styles.cover21} src={'/assets/d2d65aa573a40364d724cb33b1fba16d.png'} alt="alt text" />
      <img className={section4Styles.image7} src={'/assets/1911dd6ea8c38ae083a93fbb1021b1eb.png'} alt="alt text" />
      <img className={section4Styles.image71} src={'/assets/5232e9cdbc61e2764ada93e0341bfddd.png'} alt="alt text" />
      <img className={section4Styles.image8} src={'/assets/f297fc20acf4854490ca6473bd305519.png'} alt="alt text" />
      <img className={section4Styles.image81} src={'/assets/f297fc20acf4854490ca6473bd305519.png'} alt="alt text" />
    </section>
  );
}

export default renderSection4;
