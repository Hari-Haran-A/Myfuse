import React from 'react';
import cn from 'classnames';

import section14Styles from './section14.module.scss';

function renderSection14(props) {
  return (
    <section className={section14Styles.section14}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <div className={section14Styles.box4}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <h5 className={section14Styles.highlight3}>Join our newsletter to stay up to date on features and releases.</h5>
        <div className={section14Styles.box5}>
          <h5 className={section14Styles.highlight5}>Enter your email</h5>
        </div>
        <div className={section14Styles.box6}>
          <h5 className={section14Styles.highlight7}>Subscribe</h5>
        </div>
        <p className={section14Styles.desc_box}>
          <span className={section14Styles.desc}>
            <span className={section14Styles.desc_span0}>By subscribing you agree to with our </span>
            <span className={section14Styles.desc_span1}>Privacy Policy</span>
            <span className={section14Styles.desc_span2}>
              {' '}
              and provide consent to receive updates from our company.
            </span>
          </span>
        </p>
        <img className={section14Styles.image24} src={'/assets/62e6b4bb68fcd074dcb26a318c727f1e.png'} alt="alt text" />
        <h5 className={section14Styles.highlight10}>Useful Links</h5>
        <div className={section14Styles.text1}>Home</div>
        <div className={section14Styles.text11}>About us</div>
        <div className={section14Styles.text12}>Login</div>
        <div className={section14Styles.text13}>Terms of Service</div>
        <div className={section14Styles.text14}>Privacy Policy</div>
        <h5 className={section14Styles.highlight101}>Our Services</h5>
        <div className={section14Styles.text15}>Application</div>
        <div className={section14Styles.text16}>Legal Policy</div>
        <div className={section14Styles.text17}>Systems</div>
        <div className={section14Styles.text18}>About</div>
        <div className={section14Styles.text19}>FAQ’s</div>
        <p className={section14Styles.paragraph_box}>
          <span className={section14Styles.paragraph}>
            <span className={section14Styles.paragraph_span0}>
              MyFuse.in Residency Rd, Shanthala Nagar Ashok Nagar, Bengaluru Karnataka 560025
              <br />
            </span>
            <span className={section14Styles.paragraph_span1}>
              <br />
                Phone: +91 7975364977 Email: contact@myfuse.in
            </span>
          </span>
        </p>
        <h5 className={section14Styles.highlight102}>Contact us</h5>
      </div>
      <div className={section14Styles.text110_box}>
        <span className={section14Styles.text110}>
          <span className={section14Styles.text110_span0}>
            Copyright ©2024 MyFuse.In. All Rights Reserved Empowering digital experiences, managed and developed by 
          </span>
          <span className={section14Styles.text110_span1}>Ashutosh Kumar</span>
        </span>
      </div>
    </section>
  );
}

export default renderSection14;
