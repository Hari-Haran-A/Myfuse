import React from 'react';
import cn from 'classnames';

import section9Styles from './section9.module.scss';

function renderSection9(props) {
  return (
    <section className={section9Styles.section9}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <h1 className={section9Styles.hero_title}>BLOGS</h1>
      <h2 className={section9Styles.medium_title1}>Explore Insights and Inspiration: Dive into Our Latest Blogs</h2>
      <img className={section9Styles.image12} src={'/assets/d8cb11c0adb23767a8e192caa00d4ef0.png'} alt="alt text" />
      <div className={section9Styles.text}>Technology</div>
      <h2 className={section9Styles.medium_title4}>Unlocking Your Professional Future:</h2>
      <h5 className={section9Styles.highlight3}>
        Unlock boundless career opportunities and shape your professional future with Cisco
      </h5>
      <img className={section9Styles.image13} src={'/assets/5c669aa985d9f6cbe18f1c0f688c6cde.png'} alt="alt text" />
      <div className={section9Styles.text1}>Edward Simon</div>
      <div className={section9Styles.text11}>11 Jan 2024</div>
      <h4 className={section9Styles.highlight6}>•</h4>
      <div className={section9Styles.text12}>5 min read</div>
      <img className={section9Styles.image14} src={'/assets/3d2a402d6cd75205d39f151c6fd02723.png'} alt="alt text" />
      <div className={section9Styles.text2}>Multinational Ridesharing Company</div>
      <h2 className={section9Styles.medium_title41}>Tata Motors to set their new SUV Vehicle </h2>
      <h5 className={section9Styles.highlight31}>
        Tata Motors unveils its latest SUV, setting a new benchmark in automotive innovation
      </h5>
      <img className={section9Styles.image131} src={'/assets/b59868ff74d70cfcc124e1228ece63d5.png'} alt="alt text" />
      <div className={section9Styles.text3}>Catie Perry</div>
      <div className={section9Styles.text13}>29 Sep 2023</div>
      <h4 className={section9Styles.highlight61}>•</h4>
      <div className={section9Styles.text14}>20 min read</div>
      <img className={section9Styles.image15} src={'/assets/018456300c6cf7c162e1f0336e341c26.png'} alt="alt text" />
      <div className={section9Styles.text4}>Technology</div>
      <h2 className={section9Styles.medium_title42}>
        Navigating the Data Landscape: Insights from Data Patterns Experts
      </h2>
      <h5 className={section9Styles.highlight32}>
        Gain valuable insights from Data Patterns experts, navigating the data landscape with precision
      </h5>
      <img className={section9Styles.image132} src={'/assets/ec324b1f034ce1b50f0b6aeb66d13c44.png'} alt="alt text" />
      <div className={section9Styles.text5}>August Brunner</div>
      <div className={section9Styles.text15}>08 Aug 2023</div>
      <h4 className={section9Styles.highlight62}>•</h4>
      <div className={section9Styles.text16}>15 min read</div>
      <img className={section9Styles.image16} src={'/assets/a6cc80f15184940dec70452a9acdff52.png'} alt="alt text" />
      <div className={section9Styles.text6}>E commerce</div>
      <h2 className={section9Styles.medium_title43}>{`Revolutionizing Industries: NCR's Impact on Commerce`}</h2>
      <h5 className={section9Styles.highlight33}>
        NCR redefines commerce with groundbreaking innovations, revolutionizing industries worldwide
      </h5>
      <img className={section9Styles.image133} src={'/assets/395fa10a6543bbdee95f948f18ace833.png'} alt="alt text" />
      <div className={section9Styles.text7}>Annie Marie</div>
      <div className={section9Styles.text17}>28 May 2023</div>
      <h4 className={section9Styles.highlight63}>•</h4>
      <div className={section9Styles.text18}>35 min read</div>
      <div className={section9Styles.box1}>
        <h5 className={section9Styles.highlight7}>View all</h5>
      </div>
    </section>
  );
}

export default renderSection9;
