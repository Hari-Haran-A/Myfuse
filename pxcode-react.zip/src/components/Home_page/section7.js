import React from 'react';
import cn from 'classnames';

import section7Styles from './section7.module.scss';

function renderSection7(props) {
  return (
    <section className={section7Styles.section7}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <div className={section7Styles.rect4} />
      <img className={section7Styles.cover3} src={'/assets/38c96de3b01e165e3ffdd329f572d6ff.png'} alt="alt text" />
      <h1 className={section7Styles.hero_title1}>Create Impact with Your AI Resume Online</h1>
      <h4
        className={
          section7Styles.highlight4
        }>{`Unlock Career Opportunities: Discover AI's Potential with Your Online Resume`}</h4>
      <div className={section7Styles.box}>
        <h5 className={section7Styles.highlight5}>Enter your email</h5>
      </div>
      <div className={section7Styles.rect5} />
      <h5 className={section7Styles.highlight3}>GET NOW !</h5>
      <div className={section7Styles.info}>{`"Unlock Premium Resume Templates Now: Simply Enter Your Email!"`}</div>
    </section>
  );
}

export default renderSection7;
