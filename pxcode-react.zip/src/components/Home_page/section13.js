import React from 'react';
import cn from 'classnames';

import section13Styles from './section13.module.scss';

function renderSection13(props) {
  return (
    <section className={section13Styles.section13}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <div className={section13Styles.rect12} />
      <img className={section13Styles.cover7} src={'/assets/1ec2b386c986e4a8867a259b2e6c5dd6.png'} alt="alt text" />
      <h1 className={section13Styles.hero_title4}>Medium length heading goes here</h1>
      <h4
        className={
          section13Styles.highlight4
        }>{`Stay Ahead of the Curve! Don't Miss a Beat with Our Exclusive Updates. Sign Up for Our Newsletter and Get Fresh Insights Delivered Directly to You !`}</h4>
      <div className={section13Styles.box2}>
        <h5 className={section13Styles.highlight5}>Enter your email</h5>
      </div>
      <div className={section13Styles.box3}>
        <h5 className={section13Styles.highlight7}>Sign Up</h5>
      </div>
      <div className={section13Styles.info_box}>
        <span className={section13Styles.info}>
          <span
            className={
              section13Styles.info_span0
            }>{`By clicking Sign Up you're confirming that you agree with our `}</span>
          <span className={section13Styles.info_span1}>Terms and Conditions</span>
          <span className={section13Styles.info_span2}>.</span>
        </span>
      </div>
    </section>
  );
}

export default renderSection13;
