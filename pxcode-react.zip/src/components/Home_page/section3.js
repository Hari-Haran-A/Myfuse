import React from 'react';
import cn from 'classnames';

import section3Styles from './section3.module.scss';

function renderSection3(props) {
  return (
    <section className={section3Styles.section3}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <h1 className={section3Styles.hero_title}>CHALLENGES</h1>
      <img className={section3Styles.cover} src={'/assets/923de461d36178ca68ab3b56d53caab4.png'} alt="alt text" />
      <h2 className={section3Styles.medium_title}>{`Re-imagine MyFuse: Design & Code Competition`}</h2>
      <h3 className={section3Styles.subtitle}>
        Design your Future,  <br />          Code your Success
      </h3>
      <img className={section3Styles.image} src={'/assets/19831cb7977642fed36fcba333cfa643.png'} alt="alt text" />
      <div className={section3Styles.rect} />
      <img className={section3Styles.image1} src={'/assets/1221205d897e60579e29bb59e1c2094a.png'} alt="alt text" />
      <h4 className={section3Styles.highlight}>Rs. 15,000</h4>
      <img className={section3Styles.cover1} src={'/assets/dd0ae4c9eabe364b9a5e67259d02cb6b.png'} alt="alt text" />
      <h4 className={section3Styles.highlight1}>Registration</h4>
      <img className={section3Styles.image2} src={'/assets/dda8a51921acbcf7db9aa7f7a33a5eb3.png'} alt="alt text" />
      <img className={section3Styles.image3} src={'/assets/9124d93e131897b068ab052fa4062ec2.png'} alt="alt text" />
      <img className={section3Styles.image4} src={'/assets/026d0dedc0a2f9338704d2202f49b16c.png'} alt="alt text" />
      <h3 className={section3Styles.subtitle4}>
        Elevate your skills and embrace growth with our Regular Challenge – a daily journey to unlock your full
        potential.
      </h3>
    </section>
  );
}

export default renderSection3;
