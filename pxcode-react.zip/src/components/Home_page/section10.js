import React from 'react';
import cn from 'classnames';

import section10Styles from './section10.module.scss';

function renderSection10(props) {
  return (
    <section className={section10Styles.section10}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <h1 className={section10Styles.hero_title}>HOW IT WORKS</h1>
      <h2 className={section10Styles.medium_title1}>Explore Insights and Inspiration: Dive into Our Latest Blogs</h2>
      <img className={section10Styles.cover4} src={'/assets/fd5255b0f4097f53c9da5b9b34f3ba98.png'} alt="alt text" />
      <h1 className={section10Styles.hero_title2}>Job Hunt</h1>
      <img className={section10Styles.cover5} src={'/assets/ad3b6680c657279e8e4c61cd7b34d3bc.png'} alt="alt text" />
      <h4 className={section10Styles.highlight6}>
        Seeking your next career move? Browse our job listings for the perfect match. Your dream job awaits
      </h4>
      <img className={section10Styles.cover6} src={'/assets/a49c843e8369dc8923b2702a4a134042.png'} alt="alt text" />
      <img className={section10Styles.image17} src={'/assets/1d876d4d0377a55d7ab052c9f8704dd7.png'} alt="alt text" />
      <h1 className={section10Styles.hero_title21}>Seek Employment</h1>
      <h1 className={section10Styles.big_title}>Land your job</h1>
      <img className={section10Styles.image171} src={'/assets/1d876d4d0377a55d7ab052c9f8704dd7.png'} alt="alt text" />
      <img className={section10Styles.image172} src={'/assets/1d876d4d0377a55d7ab052c9f8704dd7.png'} alt="alt text" />
      <h4 className={section10Styles.highlight61}>
        Elevate your career today! Explore our openings and apply now for your dream job.
      </h4>
      <h4 className={section10Styles.highlight62}>Unlock your dream job with just a click! Explore our listings now</h4>
      <img className={section10Styles.image18} src={'/assets/efd57e8529845e8e7467e45c7f5001ea.png'} alt="alt text" />
    </section>
  );
}

export default renderSection10;
