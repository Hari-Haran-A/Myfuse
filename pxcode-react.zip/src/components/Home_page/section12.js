import React from 'react';
import cn from 'classnames';

import section12Styles from './section12.module.scss';

function renderSection12(props) {
  return (
    <section className={section12Styles.section12}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <h1 className={section12Styles.hero_title3}>Contact Us</h1>
      <div className={section12Styles.rect21} />
      <img className={section12Styles.image35} src={'/assets/75adf07f2014b8cfc47a9c1ff0c59945.png'} alt="alt text" />
      <h5 className={section12Styles.highlight3}>Name</h5>
      <div className={section12Styles.box21} />
      <h5 className={section12Styles.highlight31}>Email</h5>
      <div className={section12Styles.box211} />
      <h5 className={section12Styles.highlight32}>Message</h5>
      <div className={section12Styles.box22}>
        /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
        <h5 className={section12Styles.highlight5}>Type your message...</h5>
        <img className={section12Styles.image36} src={'/assets/73b36746655f3d034bae4bfc4e730453.png'} alt="alt text" />
        <img className={section12Styles.image37} src={'/assets/f22d81c718e36bf29e4a6c9d62937784.png'} alt="alt text" />
      </div>
      <div className={section12Styles.rect23} />
      <div className={section12Styles.text1_box}>
        <span className={section12Styles.text1}>
          <span className={section12Styles.text1_span0}>I accept the </span>
          <span className={section12Styles.text1_span1}>Terms</span>
        </span>
      </div>
      <div className={section12Styles.box23}>
        <h5 className={section12Styles.highlight7}>Submit</h5>
      </div>
    </section>
  );
}

export default renderSection12;
