import React from 'react';
import cn from 'classnames';

import section6Styles from './section6.module.scss';

function renderSection6(props) {
  return (
    <section className={section6Styles.section6}>
      /*This group structure is not ready for flow layout, please resolve the ❗unstructured items in pxCode editor.*/
      <h1 className={section6Styles.hero_title}>COMPANY SPOTLIGHT</h1>
      <img className={section6Styles.image10} src={'/assets/c44396aa83cbfc95b743615cfe5c3da9.png'} alt="alt text" />
      <div className={section6Styles.rect3} />
      <h2 className={section6Styles.medium_title3}>Set Clear Goals</h2>
      <h5 className={section6Styles.highlight3}>
        Clarify career goals before starting academic/professional journey to choose right paths.
      </h5>
      <img className={section6Styles.image101} src={'/assets/c44396aa83cbfc95b743615cfe5c3da9.png'} alt="alt text" />
      <div className={section6Styles.rect31} />
      <h2 className={section6Styles.medium_title31}>Develop Soft Skills</h2>
      <h5 className={section6Styles.highlight31}>
        Practice teamwork and communication via group projects, presentations, and extracurriculars to improve soft
        skills.
      </h5>
      <img className={section6Styles.image102} src={'/assets/c44396aa83cbfc95b743615cfe5c3da9.png'} alt="alt text" />
      <div className={section6Styles.rect32} />
      <h2 className={section6Styles.medium_title32}>Gain Practical Experience</h2>
      <h5 className={section6Styles.highlight32}>
        Gain a competitive advantage by finding co-ops, internships, and part-time work that fit career goals.
      </h5>
      <img className={section6Styles.image103} src={'/assets/c44396aa83cbfc95b743615cfe5c3da9.png'} alt="alt text" />
      <div className={section6Styles.rect33} />
      <h2 className={section6Styles.medium_title33}>Work on portfolio</h2>
      <h5 className={section6Styles.highlight33}>
        Showcase your best work and education in a polished portfolio to demonstrate your abilities.
      </h5>
      <img className={section6Styles.image104} src={'/assets/c44396aa83cbfc95b743615cfe5c3da9.png'} alt="alt text" />
      <h2 className={section6Styles.medium_title34}>Seek Mentorship</h2>
      <h5 className={section6Styles.highlight34}>
        Connect with experienced professionals in your field for advice and guidance to advance your career.
      </h5>
      <img className={section6Styles.image11} src={'/assets/8dedac11ab37cfbf4cdcdfd2280b700e.png'} alt="alt text" />
      <h2
        className={
          section6Styles.medium_title1
        }>{`Discover the company's mission, values, and accomplishments in Spotlight.`}</h2>
    </section>
  );
}

export default renderSection6;
